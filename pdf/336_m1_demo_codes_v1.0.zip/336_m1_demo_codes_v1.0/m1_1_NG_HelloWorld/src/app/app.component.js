"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/* Import the Component Dependency from Angular Core */
var core_1 = require("@angular/core");
/* Components annotation declare metadata for the components */
/* Components are Directives with functionality and view */
/* Template or TemplateUrl provide the views or template for the component */
/* Selector is the reference for the component and how it has to be referenced in the app view */
/* Expressions bind modelname in view and taken from the defined Class's anyModelName */
var AppComponent = (function () {
    function AppComponent() {
        this.anyModelName = "Edureka - AngularJS Introduction.";
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: '<span style="text-align:center"><h1>Hello World : {{anyModelName}}</h1></span>'
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map