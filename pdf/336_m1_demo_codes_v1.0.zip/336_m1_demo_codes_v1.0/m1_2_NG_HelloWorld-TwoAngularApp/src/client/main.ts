import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {ClientModule} from './app.module';

platformBrowserDynamic().bootstrapModule(ClientModule);
